class ul
{
public static void main(String[] args) {
  char a='a';
  if (Character.isUpperCase(a)) {
    System.out.print(Character.toLowerCase(a));
  }
  else
  {
    System.out.print(Character.toUpperCase(a));
  }
}
}
