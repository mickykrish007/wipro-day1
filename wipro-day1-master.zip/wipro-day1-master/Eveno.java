class Eveno
{
 public static void main(String[] args) {
  int x=Integer.parseInt(args[0]);
  if(x%2==0)
  System.out.print("even number");
  else
  System.out.print("odd number");
}
}
