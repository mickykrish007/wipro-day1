class sortalpha
{
public static void main(String[] args) {
  char a='a',b='e';
  if (a<b) {
    System.out.print(a+","+b);
  }
  else
  {
    System.out.print(b+","+a);
  }
}

}
